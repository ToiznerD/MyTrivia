import {TitleBlock, TextBlock, ColumnBlock} from './classes/block'
//data

export let easy = document.createElement('button')
easy.className = "btn btn-success"
easy.innerText = "Easy"
easy.type = "button"
easy.addEventListener('click', () => {
  console.log("easy clicked")
})


export let medium = document.createElement('button')
medium.className = "btn btn-warning"
medium.innerText = "Medium"
medium.type = "button"
medium.addEventListener('click', () => {
  console.log("medium clicked")
})

export let hard = document.createElement('button')
hard.className = "btn btn-danger"
hard.innerText = "Hard"
hard.type = "button"
hard.addEventListener('click', () => {
  console.log("hard clicked")
})

export let model = [
    new TitleBlock('My Trivia'),
    new TextBlock("<h3>Please choose difficulty level:</h3>"),
]

export const loadModel = () => {
    return new Promise((resolve, reject) => {
      try {
        model.push(new ColumnBlock([easy, medium, hard]))
        resolve()
      } catch (error) {
        reject(error)
      }
    })
  }

