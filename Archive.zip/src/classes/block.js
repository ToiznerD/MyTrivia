import {col,row} from './utils';

export class Block{
    constructor(type, value){
        this.type = type;
        this.value = value;
    }

    toHTML(){
        throw new Error('Not implemented');
    }
}

export class TitleBlock extends Block{
    constructor(value){
        super('title', value);
    }
    toHTML(){
        return row(col(`<center><h1>${this.value}</h1></center>`));
    }
}

export class TextBlock extends Block{
    constructor(value){
        super('text', value);
    }
    toHTML(){
        return row(col(`<p>${this.value}</p>`));
    }
}

export class ColumnBlock extends Block {
    constructor(value) {
      super('columns', value);
      
    }
    
    toHTML() {
      const div = document.createElement('div');
      div.classList.add('row');
  
      this.value.forEach(button => {
        const colDiv = document.createElement('div');
        colDiv.classList.add('col');
  
        colDiv.appendChild(button);
        div.appendChild(colDiv);
      });
      return div.outerHTML;
    }
  }

export class GameBlock extends Block{
    constructor(value){
        super('game', value)
        this.qnum = 0
    }
    
   //Return new question
    toHTML(){
        return row(this.value[qnum++].toHTML())
    }

}

export class QuestionBlock extends Block{
    constructor(value, a1, a2, a3, cA){
        super('question', value);
        this.ans[0] = a1;
        this.ans[1] = a2;
        this.ans[2] = a3;
        this.ans[3] = cA;
        this.cA = cA;
    }
    
    getQuestion(){
        buttons = []
        picked = new Set()
        for(let i = 0; i < 4; i++){

             //Pick a random answer
            x = Math.floor(Math.random() * 4);
            while (picked.has(x)){
                x = Math.floor(Math.random() * 4);
            }

            picked.add(x)

            button = document.createElement('button');
            button.innerHTML = this.ans[x];
            if(this.ans[x] === this.cA){
                this.correct_answer = button
            }
            button.style.classList = 'btn btn-primary btn-lg';
            button.addEventListener('click', ()=>{
                //Check if answer is correct
                if(button.innerHTML === cA){
                    button.style.classList = "btn btn-success"
                }
                else{
                    button.style.classList = "btn btn-danger"
                    this.correct_answer.style.classList = "btn btn-success"
                }
            })
            buttons.push(col(button.outerHTML))
        }

        return row(buttons.join(''))

    }

    toHTML(){
        return row(this.getQuestion())
    }
}
