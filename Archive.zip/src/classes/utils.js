
export const row = (content) => `<div class="row">${content}</div>`

export const col = (content) => `<div class="col-sm">${content}</div>`

export const startGame = () =>{
    let dif = localStorage.getItem('dif')
    //Initiate new game
    qi = 0
    correct_answers = 0
    fetch(`https://opentdb.com/api.php?amount=10&difficulty=${dif}&type=multiple`)
    .then(response => response.json())
    .then(result => arrangeQuestions(result))
    .catch(error => console.log('error', error));

}