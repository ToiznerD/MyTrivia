import {model, loadModel, addListeners} from './model'

// render
const container = document.querySelector('#app')
const render = () => {
    const html = model.map(m => m.toHTML()).join('')
    container.insertAdjacentHTML('beforeend', html)
}

// init
window.addEventListener('DOMContentLoaded', (event) => {
    loadModel().then(() => {
        render()
        
    })

  })
